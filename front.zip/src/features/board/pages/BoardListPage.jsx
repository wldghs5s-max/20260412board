import React from "react";

function BoardListPage() {
  return (
    <>
      <h1>BoardListPage</h1>
    </>
  );
}

export default BoardListPage;
