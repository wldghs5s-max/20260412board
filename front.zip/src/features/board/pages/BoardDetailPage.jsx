import React from "react";

function BoardDetailPage() {
  return (
    <>
      <h1>BoardDetailPage</h1>
    </>
  );
}

export default BoardDetailPage;
