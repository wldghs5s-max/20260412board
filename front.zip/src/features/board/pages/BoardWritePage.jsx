import React from "react";

function BoardWritePage() {
  return (
    <>
      <h1>BoardWritePage</h1>
    </>
  );
}

export default BoardWritePage;
