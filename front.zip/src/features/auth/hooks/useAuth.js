// useAuth.js
import { setAuth, clearAuth } from "../../../store/authStore";
import { loginApi } from "../../../api/authApi";

export default function useAuth() {
  const login = async (loginData) => {
    try {
      const resp = await loginApi(loginData);
      const { token, user } = resp.data;

      setAuth({ token, user });

      return true;
    } catch (e) {
      return false;
    }
  };

  const logout = () => {
    clearAuth();
  };

  return { login, logout };
}
