import React from "react";

function MemberListPage() {
  return (
    <>
      <h1>MemberListPage</h1>
    </>
  );
}

export default MemberListPage;
