// src/features/auth/pages/LoginPage.jsx
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import useAuth from "../hooks/useAuth";

function LoginPage() {
  const [form, setForm] = useState({
    username: "",
    password: "",
  });

  const { login } = useAuth();
  const navigate = useNavigate();

  function handleChange(e) {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  }

  async function handleLogin(e) {
    e.preventDefault();

    const success = await login(form);

    if (success) {
      navigate("/board");
    } else {
      alert("로그인 실패");
    }
  }

  return (
    <div>
      <h1>로그인</h1>

      <form onSubmit={handleLogin}>
        <input
          name="username"
          placeholder="아이디"
          value={form.username}
          onChange={handleChange}
        />

        <input
          type="password"
          name="password"
          placeholder="비밀번호"
          value={form.password}
          onChange={handleChange}
        />

        <button type="submit">로그인</button>
      </form>
    </div>
  );
}

export default LoginPage;
