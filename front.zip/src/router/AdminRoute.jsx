// src/router/AdminRoute.jsx
import { Navigate } from "react-router-dom";
import { getUser } from "../store/authStore";

function AdminRoute({ children }) {
  const user = getUser();

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  if (user.role !== "ADMIN") {
    return <Navigate to="/board" replace />;
  }

  return children;
}

export default AdminRoute;
