// src/router/ProtectedRoute.jsx
import { Navigate } from "react-router-dom";
import { getUser } from "../store/authStore";

function ProtectedRoute({ children }) {
  const user = getUser();

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  return children;
}

export default ProtectedRoute;
