// src/router/index.jsx
import { Routes, Route } from "react-router-dom";

import LoginPage from "../features/auth/pages/LoginPage";
import JoinPage from "../features/auth/pages/JoinPage";

import BoardListPage from "../features/board/pages/BoardListPage";
import BoardDetailPage from "../features/board/pages/BoardDetailPage";
import BoardWritePage from "../features/board/pages/BoardWritePage";

import MemberListPage from "../features/admin/pages/MemberListPage";

import ProtectedRoute from "./ProtectedRoute";
import AdminRoute from "./AdminRoute";

function Router() {
  return (
    <Routes>
      {/* 인증 */}
      <Route path="/login" element={<LoginPage />} />
      <Route path="/join" element={<JoinPage />} />

      {/* 게시판 (로그인 필요) */}
      <Route
        path="/board"
        element={
          <ProtectedRoute>
            <BoardListPage />
          </ProtectedRoute>
        }
      />

      <Route
        path="/board/:id"
        element={
          <ProtectedRoute>
            <BoardDetailPage />
          </ProtectedRoute>
        }
      />

      <Route
        path="/board/write"
        element={
          <ProtectedRoute>
            <BoardWritePage />
          </ProtectedRoute>
        }
      />

      {/* 관리자 */}
      <Route
        path="/admin/members"
        element={
          <AdminRoute>
            <MemberListPage />
          </AdminRoute>
        }
      />
    </Routes>
  );
}

export default Router;
