import React from "react";

function MainLayout() {
  return (
    <>
      <h1>MainLayout</h1>
    </>
  );
}

export default MainLayout;
