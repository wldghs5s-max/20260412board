// src/pages/BoardListPage.jsx
import { useEffect, useState } from "react";
import { getBoardList } from "../api/boardApi";
import { useNavigate } from "react-router-dom";
import styled from "styled-components";

const Container = styled.div`
  padding: 12px;
`;

const Item = styled.div`
  padding: 14px;
  border-bottom: 1px solid #eee;
  cursor: pointer;

  &:hover {
    background-color: #fafafa;
  }
`;

const Title = styled.div`
  font-weight: bold;
  margin-bottom: 6px;
`;

const Writer = styled.div`
  font-size: 12px;
  color: #666;
`;

const WriteBtn = styled.button`
  position: fixed;
  bottom: 20px;
  right: calc(50% - 200px);

  width: 50px;
  height: 50px;
  border-radius: 50%;

  background-color: #3b82f6;
  color: white;
  font-size: 24px;
  border: none;
  cursor: pointer;
`;

function BoardListPage() {
  const [list, setList] = useState([]);
  const navigate = useNavigate();

  async function fetchList() {
    const resp = await getBoardList();
    setList(resp.data);
  }

  useEffect(() => {
    fetchList();
  }, []);

  return (
    <Container>
      <h1>게시판 목록</h1>

      {list.map((item) => (
        <Item
          key={item.no}
          onClick={() => navigate(`/board/${item.no}`)}
          style={{ cursor: "pointer", borderBottom: "1px solid #ddd" }}
        >
          <Title>{item.title}</Title>
          <Writer>{item.writer}</Writer>
        </Item>
      ))}
      <WriteBtn onClick={() => navigate("/write")}>+</WriteBtn>
    </Container>
  );
}

export default BoardListPage;
