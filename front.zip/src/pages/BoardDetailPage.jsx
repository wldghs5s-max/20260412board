// src/pages/BoardDetailPage.jsx
import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { getBoardDetail, deleteBoard } from "../api/boardApi";

import styled from "styled-components";

const Container = styled.div`
  padding: 16px;
`;

const Title = styled.div`
  font-size: 20px;
  font-weight: bold;
  margin-bottom: 10px;
`;

const Writer = styled.div`
  font-size: 13px;
  color: #666;
  margin-bottom: 16px;
`;

const Content = styled.div`
  line-height: 1.5;
  margin-bottom: 20px;
`;

const ActionBox = styled.div`
  display: flex;
  justify-content: flex-end;
`;

const DeleteBtn = styled.button`
  padding: 10px 14px;
  border-radius: 8px;
  border: none;
  background-color: #ef4444;
  color: white;
  cursor: pointer;
`;

function BoardDetailPage() {
  const { no } = useParams();
  const [data, setData] = useState(null);
  const navigate = useNavigate();

  async function fetchDetail() {
    const resp = await getBoardDetail(no);
    setData(resp.data);
  }

  async function handleDelete() {
    if (!window.confirm("삭제하시겠습니까?")) return;

    await deleteBoard(no);
    navigate("/");
  }

  useEffect(() => {
    fetchDetail();
  }, []);

  if (!data) return <div>로딩중...</div>;

  return (
    <Container>
      <Title>{data.title}</Title>
      <Writer>{data.writer}</Writer>
      <Content>{data.content}</Content>

      <ActionBox>
        <DeleteBtn onClick={handleDelete}>삭제</DeleteBtn>
      </ActionBox>
    </Container>
  );
}

export default BoardDetailPage;
