// src/pages/BoardWritePage.jsx
import { useState } from "react";
import { createBoard } from "../api/boardApi";
import { useNavigate } from "react-router-dom";

import styled from "styled-components";

const Container = styled.div`
  padding: 20px 16px;
  display: flex;
  flex-direction: column;
  gap: 14px;
`;

const Input = styled.input`
  width: 100%;
  padding: 12px;
  border: 1px solid #ddd;
  border-radius: 10px;
  font-size: 14px;
`;

const TextArea = styled.textarea`
  width: 100%;
  min-height: 180px;
  padding: 12px;
  border: 1px solid #ddd;
  border-radius: 10px;
  resize: none;
  font-size: 14px;
`;

const SubmitBtn = styled.button`
  width: 100%;
  padding: 14px;
  border-radius: 10px;
  border: none;
  background-color: #3b82f6;
  color: white;
  font-size: 15px;
  cursor: pointer;
`;

function BoardWritePage() {
  const [form, setForm] = useState({
    title: "",
    content: "",
    writer: "",
  });

  const navigate = useNavigate();

  function handleChange(e) {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  }

  async function handleSubmit(e) {
    e.preventDefault();

    await createBoard(form);
    navigate("/");
  }

  return (
    <Container>
      <h1>글쓰기</h1>

      <form onSubmit={handleSubmit}>
        <Input name="title" placeholder="제목" onChange={handleChange} />

        <Input name="writer" placeholder="작성자" onChange={handleChange} />

        <TextArea name="content" placeholder="내용" onChange={handleChange} />

        <SubmitBtn type="submit">작성</SubmitBtn>
      </form>
      <SubmitBtn
        onClick={() => {
          navigate("/");
        }}
      >
        뒤로가기
      </SubmitBtn>
    </Container>
  );
}

export default BoardWritePage;
