import { Route, Routes } from "react-router-dom";
import "./App.css";
import BoardListPage from "./pages/BoardListPage";
import BoardWritePage from "./pages/BoardWritePage";
import BoardDetailPage from "./pages/BoardDetailPage";
function App() {
  return (
    <Routes>
      <Route path="/" element={<BoardListPage />} />
      <Route path="/board/:id" element={<BoardDetailPage />} />
      <Route path="/write" element={<BoardWritePage />} />
    </Routes>
  );
}

export default App;
