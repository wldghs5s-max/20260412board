// src/api/boardApi.js

import api from "./axios";

export const getBoardList = () => {
  return api.get("/board");
};

export const getBoardDetail = (no) => {
  return api.get(`/board/${no}`);
};

export const createBoard = (data) => {
  return api.post("/board", data);
};

export const deleteBoard = (no) => {
  return api.delete(`/board/${no}`);
};
